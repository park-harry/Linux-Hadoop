-- Upgrade MetaStore schema from 0.8.0 to 0.9.0

